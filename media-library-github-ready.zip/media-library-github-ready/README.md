# Media Library — GitHub Pages + private API + admin broadcasts

This repository is safe to publish on GitHub: **no TMDB API key, Supabase service-role key, or admin password is stored in the frontend or repository**. The browser sees only the public Supabase Edge Function URL in `config.js` (an endpoint, not a key). Credentials remain in Supabase Function Secrets.

## Files
- `index.html` — Media Library with TMDB search, saved titles, CineSRC player, loading screen and announcement popup.
- `admin.html` — separate message-sending page; the admin password is entered when sending and is not saved.
- `config.js` — public function URL only.
- `supabase/functions/site-api/index.ts` — server-side TMDB proxy and protected broadcast endpoint.
- `supabase/migrations/` — database table migration; direct browser access is revoked.
- `.github/workflows/pages.yml` — automatic GitHub Pages deploy on pushes to `main`.

## 1. Create and link a Supabase project
1. Create a project at https://supabase.com/.
2. Install the Supabase CLI: https://supabase.com/docs/guides/cli.
3. From this repository folder, run:

   ```bash
   supabase login
   supabase link --project-ref YOUR_PROJECT_REF
   supabase db push
   ```

## 2. Store secrets on Supabase (not GitHub)
Get the **TMDB API Key (v3 auth)** from your TMDB account settings. Do not use the API Read Access Token here. Create a strong, unique admin password, then run:

```bash
supabase secrets set TMDB_API_KEY='YOUR_TMDB_V3_API_KEY' ADMIN_PASSWORD='YOUR_LONG_RANDOM_ADMIN_PASSWORD' SITE_ORIGIN='https://YOUR-USERNAME.github.io'
```

For a custom domain, use its origin instead. `SITE_ORIGIN` is scheme + hostname only, with no repository path. Multiple origins can be comma-separated. Supabase supplies `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` to Edge Functions. Never copy the service-role key into a frontend file.

## 3. Deploy the backend function

```bash
supabase functions deploy site-api --no-verify-jwt
```

The function supports only the TMDB routes used by this app: `/search/movie`, `/search/tv`, `/search/person`, `/search/collection`, and `/tv/{id}`. Adult search is forced off. Broadcast sending requires the server-side admin password.

The function URL is `https://YOUR_PROJECT_REF.supabase.co/functions/v1/site-api`.

## 4. Set the public endpoint
Edit `config.js` and replace `YOUR_PROJECT_REF`:

```js
window.APP_CONFIG = {
  apiUrl: "https://YOUR_PROJECT_REF.supabase.co/functions/v1/site-api"
};
```

This URL is public and is **not an API key**. Do not put TMDB, service-role, or admin credentials here.

## 5. Publish with GitHub Pages
1. Push this folder to a GitHub repository on branch `main`.
2. In GitHub: **Settings → Pages → Build and deployment → Source → GitHub Actions**.
3. The included workflow publishes after each push.
4. Public site: `https://YOUR-USERNAME.github.io/REPOSITORY/`.
5. Admin page: `https://YOUR-USERNAME.github.io/REPOSITORY/admin.html`. Do not link it from the homepage. The page itself is not secret, but sending requires the private server-side password.

The repository may be public because it contains no credentials. Keep the admin password private. CORS restricts browser origins but is not authentication; the password is the actual authorization for sending messages.

## Broadcast behaviour
Visitors poll the function every five seconds. A new message appears on the next check, expires after 30 seconds, 1 minute, 5 minutes or 15 minutes, and can be dismissed. Visitors who open the site while a message remains active also see it.

## Security
- TMDB API key: Supabase Function Secret only.
- Supabase service-role key: server-side only.
- Admin password: Supabase Function Secret only; not embedded in HTML or saved by the admin page.
- The function URL is public because GitHub Pages is static. It is not a credential. The function limits TMDB routes and checks the admin password before broadcasting.
- Rotate secrets in Supabase if you believe they were exposed.

## Updating later
Edit the HTML/CSS/JS and `config.js` in GitHub; pushes redeploy the static site. If you change `supabase/functions/site-api/index.ts`, redeploy it with `supabase functions deploy site-api --no-verify-jwt`. Add schema changes as new migration files.

This product uses the TMDB API but is not endorsed or certified by TMDB. The embedded player is provided by CineSRC; review its terms and use it only where permitted.
