TelaView
========

A standalone browser-based movie and TV discovery page using the official TMDB API and the existing CineSRC embedded player.

Run locally
-----------
1. Keep index.html and config.js together in the same folder.
2. Open index.html in a modern browser (Chrome, Edge, Firefox or Safari).
3. If TMDB requests fail, check that config.js contains a valid TMDB API key and that the browser has an internet connection.

No backend, database, account, build step or administrator panel is required. TMDB catalogue requests and CineSRC playback are made directly by the browser.

Details interface
-----------------
- Select a movie or TV show title or poster to open the bottom-sheet details dialog.
- Close it with the close button, by clicking the dark area outside the sheet, or with Escape.
- The page behind the dialog is locked against scrolling while the dialog is open.
- TV details load season episodes from TMDB. Choose an episode and use the playback button to open it in CineSRC.

Watch history and playback
--------------------------
- Titles are added to local watch history when opened in the player.
- History is stored in this browser's localStorage and is not synced between devices.
- TV history retains the most recently opened season and episode.
- Playback position and duration are stored when the embedded CineSRC player sends its supported postMessage time-update events.
- Use the Watch History tab to resume, remove individual entries, or clear the list.

Saved titles
------------
Saved titles are stored locally in browser localStorage.

Privacy and API key
-------------------
The TMDB key is used directly in the browser. Anyone who can inspect a publicly hosted copy can view the key. Keep config.js private for a personal copy and restrict the key in your TMDB account where possible. Do not publish a private key in a public repository.

This product uses the TMDB API but is not endorsed or certified by TMDB. Playback availability is controlled by the embedded CineSRC service.
