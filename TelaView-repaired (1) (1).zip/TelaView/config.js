// Local browser configuration for TelaView.
// This TMDB key is used directly by the browser and is visible to anyone who can inspect the site.
window.APP_CONFIG = {
  tmdbApiKey: "da2cd7110866e3161b06d66aa63df0cd"
};
