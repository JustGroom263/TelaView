// Supabase Edge Function: TMDB proxy + password-protected visitor broadcasts.
// Credentials are configured as Supabase secrets; never commit them to GitHub.
const corsHeaders = (origin: string | null, allowedOrigin: string) => {
  const allowed = allowedOrigin.split(",").map((s) => s.trim()).filter(Boolean);
  const ok = !origin || allowed.length === 0 || allowed.includes(origin);
  return {"Access-Control-Allow-Origin": origin && ok ? origin : (allowed[0] || "*"), "Access-Control-Allow-Headers": "content-type", "Access-Control-Allow-Methods": "GET, POST, OPTIONS", "Vary": "Origin"};
};
const json = (body: unknown, status = 200, headers: Record<string,string> = {}) => new Response(JSON.stringify(body), {status, headers:{"Content-Type":"application/json; charset=utf-8", ...headers}});
function constantTimeEqual(a: string,b: string): boolean {const enc=new TextEncoder(),aa=enc.encode(a),bb=enc.encode(b);let diff=aa.length^bb.length;for(let i=0;i<Math.max(aa.length,bb.length);i++)diff|=(aa[i]??0)^(bb[i]??0);return diff===0;}
function allowedTmdbPath(path: unknown): path is string {if(typeof path!=="string"||path.length>120)return false;return /^\/search\/(movie|tv|person|collection)$/.test(path)||/^\/tv\/\d+$/.test(path);}
Deno.serve(async(req)=>{
 const origin=req.headers.get("origin"),allowedOrigin=Deno.env.get("SITE_ORIGIN")??"",headers=corsHeaders(origin,allowedOrigin);
 if(req.method==="OPTIONS")return new Response("ok",{headers});
 if(origin&&allowedOrigin&&!allowedOrigin.split(",").map(s=>s.trim()).includes(origin))return json({error:"Origin not allowed."},403,headers);
 const supabaseUrl=Deno.env.get("SUPABASE_URL"),serviceKey=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
 if(!supabaseUrl||!serviceKey)return json({error:"Server is not configured."},500,headers);
 const restHeaders={apikey:serviceKey,Authorization:`Bearer ${serviceKey}`,"Content-Type":"application/json"};
 if(req.method==="GET"){
  if(new URL(req.url).searchParams.get("action")!=="announcement")return json({error:"Unknown action."},400,headers);
  const query=new URL(`${supabaseUrl}/rest/v1/site_announcements`);query.searchParams.set("select","id,message,expires_at,created_at");query.searchParams.set("expires_at",`gt.${new Date().toISOString()}`);query.searchParams.set("order","created_at.desc");query.searchParams.set("limit","1");
  const result=await fetch(query,{headers:restHeaders});if(!result.ok)return json({error:"Could not load announcement."},502,headers);const rows=await result.json();return json({announcement:rows?.[0]??null},200,headers);
 }
 if(req.method!=="POST")return json({error:"Method not allowed."},405,headers);
 const raw=await req.text();if(raw.length>12000)return json({error:"Request too large."},413,headers);let body:Record<string,unknown>;try{body=JSON.parse(raw)}catch{return json({error:"Invalid JSON."},400,headers)}
 if(body.action==="tmdb"){
  const key=Deno.env.get("TMDB_API_KEY");if(!key)return json({error:"TMDB is not configured on the server."},500,headers);if(!allowedTmdbPath(body.path))return json({error:"TMDB endpoint is not allowed."},400,headers);
  const params=body.params&&typeof body.params==="object"?body.params as Record<string,unknown>:{};const target=new URL(`https://api.themoviedb.org/3${body.path}`);target.searchParams.set("api_key",key);
  for(const [name,value] of Object.entries(params)){if(!/^[a-zA-Z0-9_]+$/.test(name)||value===null||value===undefined||["api_key","api_token"].includes(name.toLowerCase()))continue;target.searchParams.set(name,String(value).slice(0,300));}
  target.searchParams.set("include_adult","false");const upstream=await fetch(target,{headers:{Accept:"application/json"}});return new Response(await upstream.text(),{status:upstream.status,headers:{...headers,"Content-Type":"application/json; charset=utf-8","Cache-Control":"public, max-age=30"}});
 }
 if(body.action==="broadcast"){
  const secret=Deno.env.get("ADMIN_PASSWORD");if(!secret||typeof body.password!=="string"||!constantTimeEqual(body.password,secret))return json({error:"Incorrect admin password."},401,headers);
  const message=typeof body.message==="string"?body.message.trim():"",duration=Number(body.durationSeconds);if(!message||message.length>500)return json({error:"Message must contain 1–500 characters."},400,headers);if(![30,60,300,900].includes(duration))return json({error:"Invalid message duration."},400,headers);
  const expiresAt=new Date(Date.now()+duration*1000).toISOString();const insert=await fetch(`${supabaseUrl}/rest/v1/site_announcements`,{method:"POST",headers:{...restHeaders,Prefer:"return=minimal"},body:JSON.stringify({message,expires_at:expiresAt})});if(!insert.ok)return json({error:"Could not save the announcement."},502,headers);
  const cleanup=new URL(`${supabaseUrl}/rest/v1/site_announcements`);cleanup.searchParams.set("expires_at",`lt.${new Date(Date.now()-7*86400000).toISOString()}`);await fetch(cleanup,{method:"DELETE",headers:restHeaders}).catch(()=>{});
  return json({ok:true,expiresAt},200,headers);
 }
 return json({error:"Unknown action."},400,headers);
});
