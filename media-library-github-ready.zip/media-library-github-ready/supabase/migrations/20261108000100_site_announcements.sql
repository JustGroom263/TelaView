create table if not exists public.site_announcements (
  id bigint generated always as identity primary key,
  message text not null check (char_length(message) between 1 and 500),
  created_at timestamptz not null default now(),
  expires_at timestamptz not null
);
create index if not exists site_announcements_active_idx on public.site_announcements (expires_at desc, created_at desc);
alter table public.site_announcements enable row level security;
revoke all on table public.site_announcements from anon, authenticated;
grant all on table public.site_announcements to service_role;
