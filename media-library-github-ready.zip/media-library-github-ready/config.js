// Public function URL only. This is an endpoint, NOT an API key.
window.APP_CONFIG = {
  apiUrl: "https://YOUR_PROJECT_REF.supabase.co/functions/v1/site-api"
};
